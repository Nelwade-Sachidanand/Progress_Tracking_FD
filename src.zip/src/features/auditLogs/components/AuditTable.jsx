import { Eye } from "lucide-react";
import { useState } from "react";
import Pagination from "../../../components/layout/Pagination";

const RECORDS_PER_PAGE = 10;

const getActionColor = (action) => {
  switch (action) {
    case "CREATE_PROJECT":
      return "bg-emerald-100 text-emerald-700";

    case "CREATE_ACTIVITY":
      return "bg-green-100 text-green-700";

    case "UPDATE_ACTIVITY":
      return "bg-blue-100 text-blue-700";

    case "UPDATE_USER":
      return "bg-cyan-100 text-cyan-700";

    case "DELETE_USER":
      return "bg-red-100 text-red-700";

    case "PHASE_CREATED":
      return "bg-violet-100 text-violet-700";

    case "MILESTONE_CREATED":
      return "bg-indigo-100 text-indigo-700";

    case "TASK_CREATED":
      return "bg-sky-100 text-sky-700";

    case "SUBTASK_CREATED":
      return "bg-teal-100 text-teal-700";

    case "Export_Excel":
      return "bg-purple-100 text-purple-700";

    case "Import_Project":
      return "bg-amber-100 text-amber-700";

    case "Upload_Activity_created":
      return "bg-lime-100 text-lime-700";

    case "Upload_Activity_Updated":
      return "bg-yellow-100 text-yellow-700";

    case "Delete_Project":
      return "bg-orange-100 text-orange-700";

    default:
      return "bg-slate-100 text-slate-700";
  }
};

export default function AuditTable({ logs = [], loading, onView }) {
  const [currentPage, setCurrentPage] = useState(1);

  if (loading) {
    return (
      <div
        className="
        bg-white
        rounded-3xl
        border
        border-slate-200
        p-10
        text-center
        text-slate-500
        "
      >
        Loading audit logs...
      </div>
    );
  }

  const totalPages = Math.max(1, Math.ceil(logs.length / RECORDS_PER_PAGE));

  const startIndex = (currentPage - 1) * RECORDS_PER_PAGE;

  const pageLogs = logs.slice(startIndex, startIndex + RECORDS_PER_PAGE);

  return (
    <div
      className="
      mt-5
      bg-white
      rounded-3xl
      border
      border-slate-200
      shadow-sm
      overflow-hidden
      "
    >
      {/* Table */}

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr
              className="
              bg-slate-50
              border-b
              border-slate-200
              "
            >
              <th
                className="
                px-6
                py-4
                text-center
                text-sm
                font-semibold
                text-slate-600
                xl:text-base 2xl:text-lg
                "
              >
                Sr. No.
              </th>

              <th
                className="
                px-6
                py-4
                text-center
                text-sm
                font-semibold
                text-slate-600
                xl:text-base 2xl:text-lg
                "
              >
                Action Type
              </th>

              <th
                className="
                px-6
                py-4
                text-center
                text-sm
                font-semibold
                text-slate-600
                xl:text-base 2xl:text-lg
                "
              >
                Entity Type
              </th>

              <th
                className="
                px-6
                py-4
                text-center
                text-sm
                font-semibold
                text-slate-600
                xl:text-base 2xl:text-lg
                "
              >
                Entity Name
              </th>

              <th
                className="
                px-6
                py-4
                text-center
                text-sm
                font-semibold
                text-slate-600
                xl:text-base 2xl:text-lg
                "
              >
                Modified By
              </th>

              <th
                className="
                px-6
                py-4
                text-center
                text-sm
                font-semibold
                text-slate-600
                xl:text-base 2xl:text-lg
                "
              >
                Modified Date
              </th>

              <th
                className="
                px-6
                py-4
                text-center
                text-sm
                font-semibold
                text-slate-600
                xl:text-base 2xl:text-lg
                "
              >
                Actions
              </th>
            </tr>
          </thead>

          <tbody>
            {pageLogs.length > 0 ? (
              pageLogs.map((log, index) => (
                <tr
                  key={log.id}
                  className="
                  border-b
                  border-slate-100
                  hover:bg-slate-50
                  transition
                  "
                >
                  {/* Sr No */}

                  <td
                    className="
                    text-center
                    px-6
                    py-5
                    font-medium
                    text-slate-700
                    text-sm
                    xl:text-base 2xl:text-lg
                    "
                  >
                    {(currentPage - 1) * RECORDS_PER_PAGE + index + 1}
                  </td>

                  {/* Action Type */}

                  <td className="px-6 py-5 text-center">
                    <span
                      className={`
                        
                      px-3
                      py-1.5
                      rounded-full
                      text-xs
                      font-medium
                      xl:text-xs 2xl:text-base
                      ${getActionColor(log.actionType)}
                      `}
                    >
                      {log.actionType}
                    </span>
                  </td>

                  {/* Entity Type */}

                  <td
                    className="
                    text-center
                    px-6
                    py-5
                    font-bold
                    text-slate-700
                    font-medium
                    text-sm
                    xl:text-sm 2xl:text-base
                    "
                  >
                    {log.entityType}
                  </td>

                  {/* Entity Name */}

                  <td
                    className="
                    text-center
                    px-6
                    py-5
                    text-slate-700
                    text-sm
                    xl:text-base 2xl:text-lg
                    "
                  >
                    {log.entityName}
                  </td>

                  {/* Modified By */}

                  <td
                    className="
                    text-center
                    px-6
                    py-5
                    text-slate-700
                    text-sm
                    xl:text-base 2xl:text-lg
                    "
                  >
                    {log.modifiedBy}
                  </td>

                  {/* Modified Date */}

                  <td
                    className="
                    text-center
                    px-6
                    py-5
                    text-slate-700
                    text-sm
                    xl:text-base 2xl:text-lg
                    "
                  >
                    {new Date(log.modifiedDate).toLocaleString()}
                  </td>

                  {/* View */}

                  <td
                    className="
                    text-center
                    px-6
                    py-5
                    "
                  >
                    <div className="flex justify-center">
                      <button
                        onClick={() => onView?.(log)}
                        className="
                        w-10
                        h-10
                        rounded-xl
                        bg-[#EEF4FF]
                        flex
                        items-center
                        justify-center
                        hover:bg-blue-100
                        transition
                        cursor-pointer
                        "
                      >
                        <Eye
                          size={16}
                          className="text-[#2563EB] 2xl:w-5 2xl:h-5"
                        />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td
                  colSpan={7}
                  className="
                  py-14
                  text-center
                  text-slate-500
                  2xl:text-base
                  "
                >
                  No audit logs found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Footer */}

      <Pagination
        currentPage={currentPage}
        totalPages={totalPages}
        totalRecords={logs.length}
        recordsPerPage={10}
        label="logs"
        onPageChange={setCurrentPage}
      />
    </div>
  );
}

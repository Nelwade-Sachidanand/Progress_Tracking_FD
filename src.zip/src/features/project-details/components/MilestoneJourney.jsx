import {
  Bug,
  ClipboardCheck,
  Database,
  FileText,
  Flag,
  GraduationCap,
  Laptop,
  Pencil,
  Rocket,
  Server,
} from "lucide-react";

export default function MilestoneJourney({ project }) {
  const icons = [
    Flag,
    FileText,
    Pencil,
    Laptop,
    Bug,
    GraduationCap,
    Database,
    Server,
    ClipboardCheck,
    Rocket,
  ];

  // Build milestone data
  const milestones =
    project?.phases?.flatMap((phase) =>
      phase.milestones?.map((milestone, index) => {
        const activities =
          milestone.tasks?.flatMap((task) =>
            task.subTasks?.flatMap(
              (subTask) => subTask.activities || []
            ) || []
          ) || [];

        const total = activities.length;

        const completed = activities.filter(
          (a) => a.executionStatus === "Completed"
        ).length;

        const inProgress = activities.filter(
          (a) => a.executionStatus === "In Progress"
        ).length;

        const delayed = activities.filter(
          (a) =>
            a.executionStatus === "Delayed" ||
            a.scheduleHealth === "Delayed"
        ).length;

        let status = "Not Started";

        if (completed === total && total > 0) {
          status = "Completed";
        } else if (delayed > 0) {
          status = "Delayed";
        } else if (completed > 0 || inProgress > 0) {
          status = "In Progress";
        }

        let color = "#94A3B8";

        if (status === "Completed") color = "#16A34A";
        if (status === "In Progress") color = "#D97706";
        if (status === "Delayed") color = "#EF4444";

        return {
          id: index,
          code: `M${String(index + 1).padStart(2, "0")}`,
          name: milestone.milestoneName,
          percentage:
            total > 0
              ? `${Math.round((completed / total) * 100)}%`
              : "0%",
          status,
          color,
          icon: icons[index % icons.length],
        };
      }) || []
    );

  // Number of milestones per row
  const itemsPerRow = 6;

  // Build snake rows automatically
  const rows = [];

  for (let i = 0; i < milestones.length; i += itemsPerRow) {
    let row = milestones.slice(i, i + itemsPerRow);

    // Reverse every alternate row
    if ((rows.length + 1) % 2 === 0) {
      row = [...row].reverse();
    }

    rows.push(row);
  }
    // -----------------------------
  // SVG Layout Configuration
  // -----------------------------
// const cardWidth = 190;
 const rowHeight = 120;
// const startX = 70;
// // const startY = 48;
// const startY = 24;
const cardWidth = 180;
const startX = 92;
const startY = 25;
const leftX = startX - 15;

//const rightX = startX + (rowLength - 1) * cardWidth + 15;

  // const svgWidth =
  //   startX * 2 +
  //   (itemsPerRow - 1) * cardWidth;
  const svgWidth =
  startX * 2 +
  (itemsPerRow - 1) * cardWidth + 35;

  const svgHeight =
    startY * 2 +
    (rows.length - 1) * rowHeight;


// -----------------------------
// Generate Snake Path
// -----------------------------
let path = "";

const curve = 20;

rows.forEach((row, rowIndex) => {

  // line should pass through icon center
//const y = startY + rowIndex * rowHeight - 8;
const y = startY + rowIndex * rowHeight + 3;
  const rowLength = row.length;

  // line starts slightly before first icon
  //const leftX = startX - 0;
  const leftX = startX - 15;

  // line ends slightly after last icon
  // const rightX =
  //   startX + (rowLength - 1) * cardWidth + 33;
const rightX =
  startX + (rowLength - 1) * cardWidth + 15;
  // const rightX =
  // startX + (rowLength - 1) * cardWidth - 8;
  if (rowIndex % 2 === 0) {

    path += `M ${leftX} ${y} H ${rightX}`;

    if (rowIndex < rows.length - 1) {

      const nextY = y + rowHeight;

      path += `
        Q ${rightX + curve} ${y}
          ${rightX + curve} ${y + curve}

        V ${nextY - curve}

        Q ${rightX + curve} ${nextY}
          ${rightX} ${nextY}
      `;
    }

  } else {

    path += `M ${rightX} ${y} H ${leftX}`;

    if (rowIndex < rows.length - 1) {

      const nextY = y + rowHeight;

      path += `
        Q ${leftX - curve} ${y}
          ${leftX - curve} ${y + curve}

        V ${nextY - curve}

        Q ${leftX - curve} ${nextY}
          ${leftX} ${nextY}
      `;
    }

  }

});
  return (
  <div className="bg-white rounded-2xl border border-[#E5EAF2] p-6 mt-4">

    {/* Header */}
    <div className="flex items-center gap-3 mb-8">

        <div
            className="
            w-8 h-
              min-w-8
  min-h-8
  shrink-0

            rounded-full
            bg-[#2563EB]
            text-white
            flex
            items-center
            justify-center
            text-sm
            font-bold
            "
          >
            3
          </div>

           <h2
  className="
  text-[16px]
  sm:text-[18px]
  lg:text-[20px]
  font-bold
  text-[#0B1F59]
  "
>
        Milestone Journey
      </h2>

    </div>

    {/* Timeline */}
    <div
      className="relative overflow-visible"
      style={{
        minHeight: svgHeight + 120,
      }}
    >

      {/* SVG Snake */}
      <svg
        width={svgWidth}
        height={svgHeight}
        className="absolute left-0 top-0 pointer-events-none"
      >

        <path
          d={path}
          fill="none"
          stroke="#CBD5E1"
          strokeWidth="3"
          strokeDasharray="10 8"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

      </svg>

      {/* Milestone Container */}
      <div
        className="relative z-10 flex flex-col"
        style={{
       gap: "32px",
        }}

      >
        {rows.map((row, rowIndex) => (
  <div
    key={rowIndex}
    className="grid"
    // style={{
    //   gridTemplateColumns: `repeat(${itemsPerRow}, ${cardWidth}px)`,
    //   justifyContent: "space-between",
    // }}
 style={{
  gridTemplateColumns: `repeat(${itemsPerRow}, ${cardWidth}px)`,
  columnGap: "8px",
  marginLeft: "-15px",
}}
  >
    {row.map((milestone, index) => {
      const Icon = milestone.icon;

      return (
        <div
          key={milestone.code}
          className="relative flex flex-col items-center group"
        >
          {/* Tooltip */}
          <div
            className="
              absolute
              hidden
              group-hover:block
              -top-12
              z-50

left-1/2
-translate-x-1/2
z-[9999]
              bg-[#0B1F59]
              text-white
              text-[11px]
              px-3
              py-2
              rounded-lg
              whitespace-nowrap
              shadow-xl
            "
          >
      
            {milestone.name}
          </div>

          {/* Circle */}
          <div
            className="
              w-9
              h-9
              rounded-full
              bg-white
              border-[3px]
              flex
              items-center
              justify-center
              relative
              z-10
            "
            style={{
              borderColor: milestone.color,
            }}
          >
            <Icon
              size={16}
              style={{
                color: milestone.color,
              }}
            />
          </div>

          {/* Milestone Code */}
          <p
            className="mt-2 text-sm font-bold"
            style={{
              color: milestone.color,
            }}
          >
            {milestone.code}
          </p>

          {/* Progress */}
          <p
            className="mt-1 text-[13px] font-bold leading-none"
            style={{
              color: milestone.color,
            }}
          >
            {milestone.percentage}
          </p>

          {/* Status */}
          <p
            className="mt-1 text-[11px] font-medium"
            style={{
              color: milestone.color,
            }}
          >
            {milestone.status}
          </p>
        </div>
      );
    })}
  </div>
))}

      </div>
            </div>
    </div>
  
);

}